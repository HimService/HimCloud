# HimDaemon/server_manager.py
import os
import time
import subprocess
import threading
from collections import defaultdict

class ServerManager:
    def __init__(self):
        self.servers = {}  # 儲存運行中的伺服器進程
        self.console_logs = defaultdict(list)  # 儲存每個伺服器的控制台日誌
        self.server_dir = os.path.join(os.path.dirname(__file__), 'servers')  # 伺服器文件目錄
        self.server_names = {}  # 儲存 ID 到名稱的映射（從 HimManager 接收）
        os.makedirs(self.server_dir, exist_ok=True)  # 確保目錄存在
        print(f"ServerManager initialized. Server directory: {self.server_dir}")  # 調試信息
        print(f"Initial server_names mapping: {self.server_names}")  # 調試初始映射

    def start_server(self, name, server_id=None):
        if name in self.servers:
            return {"success": False, "message": f"Server '{name}' is already running"}
        
        # 設置伺服器路徑和命令（Minecraft 伺服器）
        server_path = os.path.join(self.server_dir, name, 'server.jar')
        print(f"Checking server file at: {server_path}")  # 調試信息
        if not os.path.exists(server_path):
            return {"success": False, "message": f"Server file '{server_path}' not found"}
        
        # 創建伺服器目錄（如果不存在）
        os.makedirs(os.path.join(self.server_dir, name), exist_ok=True)
        
        # 運行 Minecraft 伺服器，使用 subprocess 捕獲輸出
        try:
            # 調整 Java 命令，根據需要設置記憶體（例如 -Xmx2G -Xms1G）
            print(f"Starting Minecraft server with: ['java', '-Xmx2G', '-Xms1G', '-jar', 'server.jar', 'nogui']")  # 調試信息
            process = subprocess.Popen(
                ['java', '-Xmx2G', '-Xms1G', '-jar', 'server.jar', 'nogui'],  # 根據實際需求調整
                cwd=os.path.join(self.server_dir, name),  # 設置工作目錄
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,  # 將 stderr 合併到 stdout
                text=True,
                bufsize=1,
                universal_newlines=True
            )
            self.servers[name] = {"process": process, "status": "running", "start_time": time.time()}
            if server_id is not None:
                self.server_names[server_id] = name  # 儲存 ID 到名稱的映射
                print(f"Mapping server_id {server_id} to name '{name}'")  # 調試信息
            print(f"Current server_names mapping after start: {self.server_names}")  # 調試當前映射
            
            # 啟動一個線程捕獲輸出
            def capture_output(server_name):
                while True:
                    output = process.stdout.readline()
                    if output == '' and process.poll() is not None:
                        break
                    if output:
                        self.console_logs[server_name].append(output.strip())
                        print(f"[{server_name}] {output.strip()}")  # 調試用，打印到控制台
            
            threading.Thread(target=capture_output, args=(name,), daemon=True).start()
            
            self.console_logs[name].append(f"Server {name} started at {time.ctime()}")
            return {"success": True, "message": f"Server '{name}' started"}
        except Exception as e:
            return {"success": False, "message": f"Failed to start server: {str(e)}"}

    def stop_server(self, name, server_id=None):
        if name not in self.servers:
            return {"success": False, "message": f"Server '{name}' is not running"}
        
        try:
            process = self.servers[name]["process"]
            process.terminate()  # 發出終止信號
            try:
                process.wait(timeout=10)  # 等待進程結束，最多 10 秒
            except subprocess.TimeoutExpired:
                process.kill()  # 如果進程未響應，強行殺死
            del self.servers[name]
            if server_id is not None and server_id in self.server_names and self.server_names[server_id] == name:
                del self.server_names[server_id]  # 清理映射
                print(f"Removed mapping for server_id {server_id}")  # 調試信息
            print(f"Current server_names mapping after stop: {self.server_names}")  # 調試當前映射
            self.console_logs[name].append(f"Server {name} stopped at {time.ctime()}")
            return {"success": True, "message": f"Server '{name}' stopped"}
        except Exception as e:
            return {"success": False, "message": f"Failed to stop server: {str(e)}"}

    def get_server_status(self, name_or_id):
        # 根據名稱或 ID 查詢狀態
        name = None
        if isinstance(name_or_id, int):  # 如果是 ID
            if name_or_id in self.server_names:
                name = self.server_names[name_or_id]
                print(f"Found name '{name}' for server_id {name_or_id}")  # 調試信息
            else:
                print(f"Server ID {name_or_id} not found in mappings")  # 調試信息
                return {"status": "stopped"}
        else:  # 如果是名稱
            name = name_or_id
        
        if name and name in self.servers:
            return {"status": "running", "uptime": time.time() - self.servers[name]["start_time"]}
        return {"status": "stopped"}

    def get_console_output(self, name_or_id):
        # 根據名稱或 ID 獲取控制台輸出
        name = None
        if isinstance(name_or_id, int):  # 如果是 ID
            if name_or_id in self.server_names:
                name = self.server_names[name_or_id]
                print(f"Found name '{name}' for server_id {name_or_id} in console output")  # 調試信息
            else:
                print(f"Server ID {name_or_id} not found in mappings for console output")  # 調試信息
                return {"output": "Server not found."}
        else:  # 如果是名稱
            name = name_or_id
        
        if name:
            return {"output": "\n".join(self.console_logs[name][-100:]) if self.console_logs[name] else "No output yet."}
        return {"output": "Server not found."}