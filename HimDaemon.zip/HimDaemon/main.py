from flask import Flask, request, jsonify
import os

app = Flask(__name__)

class ServerManager:
    def __init__(self):
        self.server_dir = os.path.join(os.getcwd(), "servers")
        self.server_names = {}
        os.makedirs(self.server_dir, exist_ok=True)

    def start_server(self, name, server_id=None):
        # Use name as server_id if none provided
        if server_id is None:
            server_id = name
        folder_path = os.path.join(self.server_dir, str(server_id))
        os.makedirs(folder_path, exist_ok=True)
        self.server_names[server_id] = name
        return {"success": True, "message": f"Server folder created for {name}"}

manager = ServerManager()

@app.route('/start_server', methods=['POST'])
def start_server():
    data = request.json
    name = data.get('name', '').strip()
    server_id = data.get('server_id')

    if not name:
        return jsonify({"message": "Server name is required"}), 400

    result = manager.start_server(name, server_id)
    return jsonify({"message": result["message"], "success": result["success"]}), 200

@app.route('/server/<int:server_id>/create_folder', methods=['POST'])
def create_server_folder(server_id):
    name = manager.server_names.get(server_id)
    if not name:
        return jsonify({"message": "Server not found"}), 404
    folder_path = os.path.join(manager.server_dir, str(server_id))
    os.makedirs(folder_path, exist_ok=True)
    return jsonify({"message": f"Folder {server_id} created"}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)