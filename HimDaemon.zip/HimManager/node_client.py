import requests
import json
import os

def start_server(node_url, server_name, server_id=None):
    try:
        payload = {"name": server_name.strip(), "server_id": server_id}
        if server_id is None:
            payload.pop("server_id", None)
        print(f"Sending start_server request to {node_url} with payload: {payload}")
        response = requests.post(
            f"{node_url}/start_server",
            json=payload,
            timeout=10
        )
        response.raise_for_status()
        return {"success": True, "message": response.json().get("message", "Server started successfully")}
    except requests.exceptions.RequestException as e:
        return {"success": False, "message": f"Failed to start server: {str(e)}"}

def stop_server(node_url, server_name, server_id=None):
    try:
        payload = {"name": server_name.strip(), "server_id": server_id}
        if server_id is None:
            payload.pop("server_id", None)
        print(f"Sending stop_server request to {node_url} with payload: {payload}")
        response = requests.post(
            f"{node_url}/stop_server",
            json=payload,
            timeout=10
        )
        response.raise_for_status()
        return {"success": True, "message": response.json().get("message", "Server stopped successfully")}
    except requests.exceptions.RequestException as e:
        return {"success": False, "message": f"Failed to stop server: {str(e)}"}

def upload_file(node_url, server_id, file_tuple):
    try:
        filename, file_object, content_type = file_tuple
        print(f"Uploading file {filename} to {node_url}/server/{server_id}/upload")
        response = requests.post(
            f"{node_url}/server/{server_id}/upload",
            files={'file': (filename, file_object, content_type)}
        )
        response.raise_for_status()
        return response
    except requests.exceptions.RequestException as e:
        raise e

def download_file(node_url, server_id, filename):
    try:
        print(f"Downloading file {filename} from {node_url}/server/{server_id}/download/{filename}")
        response = requests.get(
            f"{node_url}/server/{server_id}/download/{filename}",
            stream=True
        )
        response.raise_for_status()
        return response
    except requests.exceptions.RequestException as e:
        raise e

def list_items(node_url, server_id):
    try:
        print(f"Listing items from {node_url}/server/{server_id}/list_items")
        response = requests.get(
            f"{node_url}/server/{server_id}/list_items"
        )
        response.raise_for_status()
        return response.json().get("items", [])
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return []
        raise e
    except requests.exceptions.RequestException as e:
        raise e

def edit_file(node_url, server_id, filename, content):
    try:
        print(f"Editing file {filename} at {node_url}/server/{server_id}/edit_file/{filename}")
        response = requests.post(
            f"{node_url}/server/{server_id}/edit_file/{filename}",
            json={"content": content}
        )
        response.raise_for_status()
        return response
    except requests.exceptions.RequestException as e:
        raise e

def delete_file(node_url, server_id, filename):
    try:
        print(f"Deleting file {filename} from {node_url}/server/{server_id}/delete_file/{filename}")
        response = requests.post(
            f"{node_url}/server/{server_id}/delete_file/{filename}"
        )
        response.raise_for_status()
        return response
    except requests.exceptions.RequestException as e:
        raise e

def rename_file(node_url, server_id, filename, new_filename):
    try:
        print(f"Renaming file {filename} to {new_filename} at {node_url}/server/{server_id}/rename_file/{filename}")
        response = requests.post(
            f"{node_url}/server/{server_id}/rename_file/{filename}",
            json={"new_filename": new_filename}
        )
        response.raise_for_status()
        return response
    except requests.exceptions.RequestException as e:
        raise e

def create_server_folder(node_url, server_id):
    try:
        print(f"Creating folder for server_id: {server_id} at {node_url}/server/{server_id}/create_folder")
        response = requests.post(
            f"{node_url}/server/{server_id}/create_folder"
        )
        response.raise_for_status()
        return response
    except requests.exceptions.RequestException as e:
        raise e

def delete_server_folder(node_url, server_id):
    try:
        print(f"Deleting folder for server_id: {server_id} at {node_url}/server/{server_id}/delete_folder")
        response = requests.post(
            f"{node_url}/server/{server_id}/delete_folder"
        )
        response.raise_for_status()
        return response
    except requests.exceptions.RequestException as e:
        raise e