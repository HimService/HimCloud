import sqlite3

def init_db():
    conn = sqlite3.connect('himmanager.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS servers 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                  name TEXT, 
                  node_url TEXT, 
                  status TEXT DEFAULT 'stopped')''')
    conn.commit()
    conn.close()

def add_server(name, node_url):
    conn = sqlite3.connect('himmanager.db')
    c = conn.cursor()
    c.execute("INSERT INTO servers (name, node_url) VALUES (?, ?)", (name, node_url))
    conn.commit()
    conn.close()

def get_servers():
    conn = sqlite3.connect('himmanager.db')
    c = conn.cursor()
    c.execute("SELECT * FROM servers")
    servers = c.fetchall()
    conn.close()
    return servers

def delete_server(server_id):
    conn = sqlite3.connect('himmanager.db')
    c = conn.cursor()
    c.execute("DELETE FROM servers WHERE id=?", (server_id,))
    conn.commit()
    conn.close()

def update_server_name(server_id, new_name):
    conn = sqlite3.connect('himmanager.db')
    c = conn.cursor()
    c.execute("UPDATE servers SET name=? WHERE id=?", (new_name, server_id))
    conn.commit()
    conn.close()