from flask import Flask, request, jsonify
import requests
import sqlite3

app = Flask(__name__)

# Initialize the database
def init_db():
    conn = sqlite3.connect('himmanager.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS servers 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, node_url TEXT, status TEXT DEFAULT 'stopped')''')
    conn.commit()
    conn.close()

init_db()

@app.route('/create_server', methods=['POST'])
def create_server():
    data = request.json
    name = data.get('name', '').strip()
    node_url = data.get('node_url', 'http://localhost:8080')

    if not name:
        return jsonify({"message": "Server name is required"}), 400

    print(f"Creating server with name: {name}, node_url: {node_url}")
    try:
        # Send request to HimDaemon with name and server_id (initially None)
        response = requests.post(
            f"{node_url}/start_server",
            json={"name": name, "server_id": None},
            timeout=10
        )
        result = response.json()
        print(f"First start server result: {result}")

        if response.status_code == 200 and result.get("success"):
            # Insert server into database and get the generated server_id
            conn = sqlite3.connect('himmanager.db')
            c = conn.cursor()
            c.execute("INSERT INTO servers (name, node_url) VALUES (?, ?)", (name, node_url))
            conn.commit()
            server_id = c.lastrowid
            conn.close()

            # Create a folder for the server
            folder_response = requests.post(f"{node_url}/server/{server_id}/create_folder")
            if folder_response.status_code != 200:
                print(f"Folder creation failed: {folder_response.text}")
            else:
                print(f"Folder created for server_id: {server_id}")

            return jsonify({"message": "Server created successfully", "server_id": server_id}), 201
        else:
            # Return the error message from HimDaemon
            return jsonify({"message": f"Failed to start server: {result.get('message', 'Unknown error')}"}), 400
    except requests.exceptions.RequestException as e:
        return jsonify({"message": f"Failed to communicate with node: {str(e)}"}), 500
    except sqlite3.Error as e:
        return jsonify({"message": f"Database error: {str(e)}"}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)