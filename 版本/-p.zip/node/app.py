#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Node - 儲存節點
負責儲存檔案、與 Panel 溝通
"""

import os
import json
import uuid
import hashlib
import time
import shutil
import threading
from flask import Flask, request, jsonify, send_file

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB max file size

# 載入設定 (只讀取 YAML 格式)
def load_config():
    # 只讀取 YAML 格式
    config_path = os.path.join(os.path.dirname(__file__), 'config.yml')
    if os.path.exists(config_path):
        try:
            import yaml
            with open(config_path, 'r', encoding='utf-8') as f:
                raw_config = yaml.safe_load(f)
            return parse_config(raw_config)
        except ImportError:
            print("❌ PyYAML 未安裝，請執行: pip install PyYAML")
            print("❌ 程式結束")
            exit(1)
        except Exception as e:
            print(f"❌ 載入 config.yml 失敗: {e}")
            print("❌ 程式結束")
            exit(1)
    
    # config.yml 不存在
    print("❌ config.yml 不存在，請從 Panel 後台產生配置檔案")
    print("❌ 程式結束")
    exit(1)

def parse_config(raw_config):
    """解析配置"""
    config = {}
    
    # 新格式：直接從頂層讀取 (YAML)
    if 'uuid' in raw_config:
        config['uuid'] = raw_config.get('uuid')
    if 'token_id' in raw_config:
        config['token_id'] = raw_config.get('token_id')
    if 'token' in raw_config:
        config['token'] = raw_config.get('token')
    
    # node 區塊
    node_config = raw_config.get('node', {})
    config['node_name'] = node_config.get('name', 'My Node')  # 從 node.name 讀取
    config['node_host'] = node_config.get('host', '0.0.0.0')
    config['node_port'] = node_config.get('port', 443)
    config['max_file_size'] = node_config.get('max_file_size', 100 * 1024 * 1024)
    config['max_storage_size'] = node_config.get('max_storage_size', 0)
    config['storage_dir'] = node_config.get('data', 'storage')
    
    # 其他設定
    config['heartbeat_interval'] = raw_config.get('heartbeat_interval', 30)
    config['panel_url'] = raw_config.get('panel_url', 'http://localhost:5000')
    
    # 兼容舊格式（從 token.txt 讀取 Token）
    token = get_token_from_file()
    if not config.get('token'):
        config['token'] = token
    
    return config

# 從 token.txt 讀取 Token（向後兼容）
def get_token_from_file():
    token_path = os.path.join(os.path.dirname(__file__), 'token.txt')
    if os.path.exists(token_path):
        with open(token_path, 'r', encoding='utf-8') as f:
            return f.read().strip()
    return ''

# 獲取 Token
def get_token():
    # 首先從 config 讀取
    if config.get('token'):
        return config.get('token')
    # 然後從 token.txt 讀取（向後兼容）
    return get_token_from_file()

config = load_config()

# 儲存目錄
STORAGE_DIR = os.path.join(os.path.dirname(__file__), config.get('storage_dir', 'storage'))

# 確保儲存目錄存在
if not os.path.exists(STORAGE_DIR):
    os.makedirs(STORAGE_DIR)

# 元資料檔案
METADATA_FILE = os.path.join(STORAGE_DIR, 'metadata.json')

# 初始化元資料
def init_metadata():
    if not os.path.exists(METADATA_FILE):
        with open(METADATA_FILE, 'w', encoding='utf-8') as f:
            json.dump({}, f)

def load_metadata():
    try:
        with open(METADATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_metadata(metadata):
    with open(METADATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)

def calculate_checksum(data):
    """計算 SHA256 校驗碼"""
    return hashlib.sha256(data).hexdigest()

# 計算儲存空間使用量
def calculate_storage_used():
    total = 0
    metadata = load_metadata()
    for file_id, info in metadata.items():
        # 處理路徑中的正斜槓
        path = info.get('path', '').replace('/', os.sep)
        file_path = os.path.join(STORAGE_DIR, path)
        if os.path.exists(file_path):
            total += os.path.getsize(file_path)
    return total

# 計算用戶儲存空間使用量
def calculate_user_storage_used(user_id):
    total = 0
    metadata = load_metadata()
    for file_id, info in metadata.items():
        if info.get('user_id') == user_id:
            # 處理路徑中的正斜槓
            path = info.get('path', '').replace('/', os.sep)
            file_path = os.path.join(STORAGE_DIR, path)
            if os.path.exists(file_path):
                total += os.path.getsize(file_path)
    return total

# ==================== 與 Panel 通訊 ====================

# 全域變數標記節點是否被撤銷
node_revoked = False

def register_to_panel():
    """向 Panel 註冊"""
    import requests
    
    global node_revoked
    
    token = get_token()
    if not token:
        print("❌ 沒有設定 Token，無法註冊到 Panel")
        return False
    
    panel_url = config.get('panel_url', 'localhost:5000')
    if not panel_url.startswith('http'):
        panel_url = 'http://' + panel_url
    
    node_port = config.get('node_port', 5001)
    
    # 計算容量（取儲存目錄所在磁碟的可用空間）
    try:
        stat = shutil.disk_usage(STORAGE_DIR)
        capacity = stat.total
    except:
        capacity = 0
    
    storage_used = calculate_storage_used()
    
    try:
        response = requests.post(
            f"{panel_url}/api/node/register",
            json={
                'uuid': config.get('uuid', ''),
                'token_id': config.get('token_id', ''),
                'token': token,
                'name': config.get('node_name', 'My Node'),
                'host': 'localhost',
                'port': node_port,
                'capacity': capacity,
                'used': storage_used
            },
            timeout=10
        )
        
        # 檢查是否被撤銷 (403)
        if response.status_code == 403:
            result = response.json()
            error_msg = result.get('error', '節點已被移除')
            print(f"❌ 節點已被移除: {error_msg}")
            print("請聯絡管理員重新設定節點")
            node_revoked = True
            return False
        
        result = response.json()
        if result.get('success'):
            print(f"✅ 節點註冊成功: {result.get('message')}")
            node_revoked = False
            return True
        else:
            print(f"❌ 節點註冊失敗: {result.get('error')}")
            return False
    except Exception as e:
        print(f"❌ 連線 Panel 失敗: {e}")
        return False

def send_heartbeat():
    """發送心跳"""
    import requests
    
    global node_revoked
    
    token = get_token()
    if not token:
        return False
    
    # 如果節點已被撤銷，不發送心跳
    if node_revoked:
        return False
    
    panel_url = config.get('panel_url', 'localhost:5000')
    if not panel_url.startswith('http'):
        panel_url = 'http://' + panel_url
    
    try:
        stat = shutil.disk_usage(STORAGE_DIR)
        capacity = stat.total
    except:
        capacity = 0
    
    storage_used = calculate_storage_used()
    
    try:
        response = requests.post(
            f"{panel_url}/api/node/heartbeat",
            json={
                'token': token,
                'capacity': capacity,
                'used': storage_used
            },
            timeout=10
        )
        
        # 檢查是否被撤銷 (403)
        if response.status_code == 403:
            result = response.json()
            error_msg = result.get('error', '節點已被移除')
            print(f"❌ 節點已被移除: {error_msg}")
            print("請聯絡管理員重新設定節點")
            node_revoked = True
            return False
        
        return response.status_code == 200
    except:
        return False

def heartbeat_worker():
    """背景心跳執行緒"""
    import requests
    
    global node_revoked
    
    interval = config.get('heartbeat_interval', 30)
    
    # 如果節點已被撤銷，停止嘗試連線
    while not node_revoked:
        try:
            result = send_heartbeat()
            if not result and not node_revoked:
                # 檢查是否被撤銷
                token = get_token()
                if token:
                    panel_url = config.get('panel_url', 'localhost:5000')
                    if not panel_url.startswith('http'):
                        panel_url = 'http://' + panel_url
                    try:
                        response = requests.post(
                            f"{panel_url}/api/node/register",
                            json={'token': token},
                            timeout=10
                        )
                        if response.status_code == 403:
                            result = response.json()
                            error_msg = result.get('error', '節點已被移除')
                            print(f"❌ 節點已被移除: {error_msg}")
                            print("請聯絡管理員重新設定節點")
                            node_revoked = True
                            break
                    except Exception:
                        pass
        except Exception:
            pass
        time.sleep(interval)
    
    # 節點已被撤銷，停止心跳執行緒
    if node_revoked:
        print("⚠️ 心跳執行緒已停止（節點已被移除）")


# ==================== Node API ====================

@app.route('/api/node/store', methods=['POST'])
def store_file():
    """儲存檔案"""
    if 'file' not in request.files:
        return jsonify({'success': False, 'error': '無檔案'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'error': '檔案名稱為空'}), 400
    
    file_id = request.form.get('file_id')
    user_id = request.form.get('user_id', 'default')
    
    if not file_id:
        return jsonify({'success': False, 'error': '無檔案ID'}), 400
    
    # 建立用戶目錄
    user_dir = os.path.join(STORAGE_DIR, user_id)
    if not os.path.exists(user_dir):
        os.makedirs(user_dir)
    
    # 儲存檔案
    file_content = file.read()
    file_path = os.path.join(user_dir, file_id)
    
    # 使用正斜槓 (跨平台相容性)
    storage_path = user_id + '/' + file_id
    
    try:
        with open(file_path, 'wb') as f:
            f.write(file_content)
        
        # 計算校驗碼
        checksum = calculate_checksum(file_content)
        
        # 記錄元資料
        metadata = load_metadata()
        metadata[file_id] = {
            'id': file_id,
            'name': file.filename,
            'user_id': user_id,
            'path': storage_path,
            'size': len(file_content),
            'checksum': checksum,
            'uploaded_at': time.time()
        }
        save_metadata(metadata)
        
        return jsonify({
            'success': True,
            'checksum': checksum
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/node/retrieve/<file_id>', methods=['GET'])
def retrieve_file(file_id):
    """取得檔案"""
    metadata = load_metadata()
    
    if file_id not in metadata:
        return jsonify({'success': False, 'error': '檔案不存在'}), 404
    
    file_info = metadata[file_id]
    # 處理路徑中的正斜槓
    path = file_info.get('path', '').replace('/', os.sep)
    file_path = os.path.join(STORAGE_DIR, path)
    
    if not os.path.exists(file_path):
        return jsonify({'success': False, 'error': '檔案不存在'}), 404
    
    return send_file(file_path, as_attachment=True, download_name=file_info.get('name', file_id))

@app.route('/api/node/delete/<file_id>', methods=['DELETE'])
def delete_file(file_id):
    """刪除檔案"""
    metadata = load_metadata()
    
    if file_id not in metadata:
        return jsonify({'success': False, 'error': '檔案不存在'}), 404
    
    file_info = metadata[file_id]
    
    # 路徑已經包含 user_id，直接使用
    path = file_info.get('path', '')
    if not path:
        # 如果沒有路徑資訊，嘗試從 file_id 建構
        user_id = file_info.get('user_id', 'default')
        path = user_id + '/' + file_id
    
    # 正確建構檔案路徑
    file_path = os.path.join(STORAGE_DIR, path)
    
    try:
        if os.path.exists(file_path):
            os.remove(file_path)
        
        del metadata[file_id]
        save_metadata(metadata)
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/node/files', methods=['GET'])
def list_files():
    """列出所有檔案"""
    metadata = load_metadata()
    return jsonify({'success': True, 'files': metadata})

@app.route('/api/node/info', methods=['GET'])
def node_info():
    """取得節點資訊"""
    try:
        stat = shutil.disk_usage(STORAGE_DIR)
        capacity = stat.total
        used = stat.used
        free = stat.free
    except:
        capacity = used = free = 0
    
    storage_used = calculate_storage_used()
    
    return jsonify({
        'success': True,
        'info': {
            'name': config.get('node_name', 'My Node'),
            'storage_dir': STORAGE_DIR,
            'capacity': capacity,
            'used': storage_used,
            'free': capacity - storage_used,
            'file_count': len(load_metadata())
        }
    })

@app.route('/health', methods=['GET'])
def health_check():
    """健康檢查"""
    return jsonify({
        'status': 'ok',
        'timestamp': time.time()
    })

# ==================== 啟動 ====================

def main():
    init_metadata()
    
    token = get_token()
    node_name = config.get('node_name', 'My Node')
    node_port = config.get('node_port', 5001)
    
    print("=" * 50)
    print("HimService Node 啟動中...")
    print(f"節點名稱: {node_name}")
    print(f"儲存目錄: {STORAGE_DIR}")
    print(f"Panel 位址: {config.get('panel_url')}")
    print(f"Token: {token[:20]}..." if token else "Token: (未設定)")
    print("=" * 50)
    
    # 嘗試註冊到 Panel
    register_to_panel()
    
    # 啟動心跳執行緒
    heartbeat_thread = threading.Thread(target=heartbeat_worker, daemon=True)
    heartbeat_thread.start()
    
    # 啟動 Flask
    node_host = config.get('node_host', '0.0.0.0')
    print(f"✅ 節點服務啟動: http://{node_host}:{node_port}")
    app.run(host=node_host, port=node_port, debug=False)

if __name__ == '__main__':
    main()
