#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Panel - 雲端硬碟管理面板
負責對外提供服務、管理節點、用戶、處理使用者請求
"""

import os
import json
import uuid
import hashlib
import time
import io
import requests
from functools import wraps
from flask import Flask, request, jsonify, send_file, render_template_string, session, render_template
from werkzeug.utils import secure_filename

# 設定範本目錄
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, template_folder=os.path.join(BASE_DIR, 'templates'))
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max file size
app.config['SECRET_KEY'] = os.urandom(32)

# 資料儲存
NODES_FILE = 'nodes.json'
FILES_FILE = 'files.json'
USERS_FILE = 'users.json'
QUOTAS_FILE = 'quotas.json'
REVOKED_TOKENS_FILE = 'revoked_tokens.json'

# 初始化撤銷 Token 檔案
def load_revoked_tokens():
    try:
        if os.path.exists(REVOKED_TOKENS_FILE):
            with open(REVOKED_TOKENS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except:
        pass
    return []

def save_revoked_tokens(tokens):
    with open(REVOKED_TOKENS_FILE, 'w', encoding='utf-8') as f:
        json.dump(tokens, f)

def is_token_revoked(token):
    revoked_tokens = load_revoked_tokens()
    return token in revoked_tokens

def revoke_token(token):
    revoked_tokens = load_revoked_tokens()
    if token not in revoked_tokens:
        revoked_tokens.append(token)
        save_revoked_tokens(revoked_tokens)

# 初始化資料檔案
def init_data_files():
    if not os.path.exists(NODES_FILE):
        with open(NODES_FILE, 'w', encoding='utf-8') as f:
            json.dump({}, f)
    if not os.path.exists(FILES_FILE):
        with open(FILES_FILE, 'w', encoding='utf-8') as f:
            json.dump({}, f)
    if not os.path.exists(USERS_FILE):
        default_admin = {
            'admin': {
                'id': 'admin',
                'username': 'admin',
                'password': hashlib.sha256('admin123'.encode()).hexdigest(),
                'role': 'admin',
                'created_at': time.time()
            }
        }
        with open(USERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(default_admin, f, ensure_ascii=False, indent=2)
    if not os.path.exists(QUOTAS_FILE):
        with open(QUOTAS_FILE, 'w', encoding='utf-8') as f:
            json.dump({}, f)

def load_nodes():
    try:
        with open(NODES_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_nodes(nodes):
    with open(NODES_FILE, 'w', encoding='utf-8') as f:
        json.dump(nodes, f, ensure_ascii=False, indent=2)

def load_files():
    try:
        with open(FILES_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_files(files):
    with open(FILES_FILE, 'w', encoding='utf-8') as f:
        json.dump(files, f, ensure_ascii=False, indent=2)

def load_users():
    try:
        with open(USERS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_users(users):
    with open(USERS_FILE, 'w', encoding='utf-8') as f:
        json.dump(users, f, ensure_ascii=False, indent=2)

def load_quotas():
    try:
        with open(QUOTAS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {}

def save_quotas(quotas):
    with open(QUOTAS_FILE, 'w', encoding='utf-8') as f:
        json.dump(quotas, f, ensure_ascii=False, indent=2)

def generate_token():
    random_str = str(uuid.uuid4()) + str(time.time())
    return hashlib.sha256(random_str.encode()).hexdigest()

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# 認證裝飾器
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'success': False, 'error': '請先登入'}), 401
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'success': False, 'error': '請先登入'}), 401
        users = load_users()
        user = users.get(user_id, {})
        if user.get('role') != 'admin':
            return jsonify({'success': False, 'error': '權限不足'}), 403
        return f(*args, **kwargs)
    return decorated_function

# 認證 API
@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')
    
    users = load_users()
    for user_id, user in users.items():
        if user.get('username') == username:
            if user.get('password') == hash_password(password):
                session['user_id'] = user_id
                session['username'] = username
                session['role'] = user.get('role')
                return jsonify({'success': True, 'user': {'id': user_id, 'username': username, 'role': user.get('role')}})
            return jsonify({'success': False, 'error': '密碼錯誤'}), 401
    return jsonify({'success': False, 'error': '帳號不存在'}), 404

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})

@app.route('/api/auth/check', methods=['GET'])
def check_auth():
    user_id = session.get('user_id')
    if user_id:
        # 獲取用戶配額資訊
        quotas = load_quotas()
        user_quota = quotas.get(user_id, {})
        return jsonify({
            'success': True, 
            'logged_in': True, 
            'user': {
                'id': user_id, 
                'username': session.get('username'), 
                'role': session.get('role'),
                'storage_quota': user_quota.get('quota', 0),
                'storage_used': user_quota.get('used', 0)
            }
        })
    return jsonify({'success': True, 'logged_in': False})

# 用戶管理 API
@app.route('/api/user/list', methods=['GET'])
@admin_required
def list_users():
    users = load_users()
    quotas = load_quotas()
    user_list = []
    for user_id, user in users.items():
        quota = quotas.get(user_id, {})
        user_list.append({'id': user_id, 'username': user.get('username'), 'role': user.get('role'), 'created_at': user.get('created_at'), 'storage_quota': quota.get('quota', 0), 'storage_used': quota.get('used', 0)})
    return jsonify({'success': True, 'users': user_list})

@app.route('/api/user/create', methods=['POST'])
@admin_required
def create_user():
    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')
    role = data.get('role', 'user')
    
    users = load_users()
    for user in users.values():
        if user.get('username') == username:
            return jsonify({'success': False, 'error': '帳號已存在'}), 400
    
    user_id = str(uuid.uuid4())
    users[user_id] = {'id': user_id, 'username': username, 'password': hash_password(password), 'role': role, 'created_at': time.time()}
    save_users(users)
    
    quotas = load_quotas()
    quotas[user_id] = {'quota': 0, 'used': 0, 'nodes': []}
    save_quotas(quotas)
    return jsonify({'success': True, 'user_id': user_id})

@app.route('/api/user/<user_id>', methods=['DELETE'])
@admin_required
def delete_user(user_id):
    users = load_users()
    if user_id not in users:
        return jsonify({'success': False, 'error': '用戶不存在'}), 404
    if user_id == session.get('user_id'):
        return jsonify({'success': False, 'error': '不能刪除自己'}), 400
    del users[user_id]
    save_users(users)
    quotas = load_quotas()
    if user_id in quotas:
        del quotas[user_id]
        save_quotas(quotas)
    return jsonify({'success': True})

@app.route('/api/user/quota', methods=['POST'])
@admin_required
def set_user_quota():
    data = request.get_json()
    user_id = data.get('user_id')
    quota = data.get('quota', 0)
    node_ids = data.get('nodes', [])
    quotas = load_quotas()
    quotas[user_id] = {'quota': int(quota), 'used': quotas.get(user_id, {}).get('used', 0), 'nodes': node_ids}
    save_quotas(quotas)
    return jsonify({'success': True})

@app.route('/api/user/<user_id>', methods=['GET'])
@admin_required
def get_user(user_id):
    users = load_users()
    quotas = load_quotas()
    if user_id not in users:
        return jsonify({'success': False, 'error': '用戶不存在'}), 404
    user = users[user_id]
    quota = quotas.get(user_id, {})
    return jsonify({
        'success': True,
        'user': {
            'id': user_id,
            'username': user.get('username'),
            'role': user.get('role'),
            'created_at': user.get('created_at'),
            'storage_quota': quota.get('quota', 0),
            'storage_used': quota.get('used', 0),
            'allowed_nodes': quota.get('allowed_nodes', [])
        }
    })

@app.route('/api/user/<user_id>', methods=['PUT'])
@admin_required
def update_user(user_id):
    users = load_users()
    quotas = load_quotas()
    if user_id not in users:
        return jsonify({'success': False, 'error': '用戶不存在'}), 404
    
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    role = data.get('role')
    quota = data.get('storage_quota', 0)
    allowed_nodes = data.get('allowed_nodes', [])
    
    # 檢查用戶名是否重複
    if username:
        for uid, u in users.items():
            if uid != user_id and u.get('username') == username:
                return jsonify({'success': False, 'error': '帳號已存在'}), 400
        users[user_id]['username'] = username
    
    if password:
        users[user_id]['password'] = hash_password(password)
    
    if role:
        users[user_id]['role'] = role
    
    save_users(users)
    
    # 更新配額
    if user_id not in quotas:
        quotas[user_id] = {'quota': 0, 'used': 0, 'nodes': [], 'allowed_nodes': []}
    quotas[user_id]['quota'] = int(quota)
    quotas[user_id]['allowed_nodes'] = allowed_nodes
    save_quotas(quotas)
    
    return jsonify({'success': True})

# SSE
@app.route('/api/node/stream')
def node_stream():
    from flask import Response
    def generate():
        while True:
            nodes = load_nodes()
            current_time = time.time()
            for node_id, node_info in nodes.items():
                # 改為 90 秒 timeout (3 倍心跳間隔)
                node_info['status'] = 'online' if current_time - node_info.get('last_heartbeat', 0) <= 90 else 'offline'
            yield f"data: {json.dumps({'nodes': nodes, 'timestamp': current_time})}\n\n"
            time.sleep(3)
    return Response(generate(), mimetype='text/event-stream')

# Node API
@app.route('/api/node/register', methods=['POST'])
def register_node():
    data = request.get_json()
    node_token = data.get('token', '')
    node_uuid = data.get('uuid', '')  # 新增：Node UUID
    node_token_id = data.get('token_id', '')  # 新增：Token ID
    node_name = data.get('name', 'Unnamed Node')
    node_host = data.get('host', request.host)
    node_port = data.get('port', 5001)
    node_capacity = data.get('capacity', 0)
    
    # 檢查 Token 是否已被撤銷
    if is_token_revoked(node_token):
        return jsonify({'success': False, 'error': '此節點已被移除，請聯絡管理員重新設定'}), 403
    
    nodes = load_nodes()
    
    # 優先使用 uuid + token_id 來匹配節點
    for node_id, node_info in nodes.items():
        if node_uuid and node_info.get('id') == node_uuid:
            # 優先使用管理員設定的 storage_limit
            stored_capacity = node_info.get('storage_limit', 0)
            if stored_capacity == 0:
                stored_capacity = node_capacity
            node_info.update({
                'name': node_name, 
                'host': node_host, 
                'port': node_port, 
                'last_heartbeat': time.time(), 
                'status': 'online', 
                'capacity': stored_capacity
            })
            save_nodes(nodes)
            return jsonify({'success': True, 'message': '節點已存在', 'node_id': node_id})
    
    # 如果沒有 uuid，則使用 token 匹配（向後兼容）
    for node_id, node_info in nodes.items():
        if node_info.get('token') == node_token:
            # 優先使用管理員設定的 storage_limit
            stored_capacity = node_info.get('storage_limit', 0)
            if stored_capacity == 0:
                stored_capacity = node_capacity
            node_info.update({
                'name': node_name, 
                'host': node_host, 
                'port': node_port, 
                'last_heartbeat': time.time(), 
                'status': 'online', 
                'capacity': stored_capacity
            })
            save_nodes(nodes)
            return jsonify({'success': True, 'message': '節點已存在', 'node_id': node_id})
    
    # 新節點註冊
    node_id = node_uuid if node_uuid else str(uuid.uuid4())
    nodes[node_id] = {
        'id': node_id, 
        'name': node_name, 
        'token': node_token, 
        'token_id': node_token_id,
        'host': node_host, 
        'port': node_port, 
        'registered_at': time.time(), 
        'last_heartbeat': time.time(), 
        'status': 'online', 
        'capacity': node_capacity, 
        'used': 0
    }
    save_nodes(nodes)
    return jsonify({'success': True, 'message': '節點註冊成功', 'node_id': node_id})

@app.route('/api/node/heartbeat', methods=['POST'])
def node_heartbeat():
    data = request.get_json()
    node_token = data.get('token', '')
    
    # 檢查 Token 是否已被撤銷
    if is_token_revoked(node_token):
        return jsonify({'success': False, 'error': '節點已被移除'}), 403
    
    nodes = load_nodes()
    for node_id, node_info in nodes.items():
        if node_info.get('token') == node_token:
            # 優先使用管理員設定的 storage_limit，如果沒有則使用 Node 匯報的值
            node_capacity = node_info.get('storage_limit', 0)
            if node_capacity == 0:
                node_capacity = data.get('capacity', node_info.get('capacity', 0))
            node_info.update({'last_heartbeat': time.time(), 'status': 'online', 'capacity': node_capacity, 'used': data.get('used', 0)})
            save_nodes(nodes)
            return jsonify({'success': True})
    return jsonify({'success': False, 'error': '節點未找到'}), 404

@app.route('/api/node/list', methods=['GET'])
@login_required
def list_nodes():
    user_id = session.get('user_id')
    role = session.get('role')
    quotas = load_quotas()
    user_quota = quotas.get(user_id, {})
    allowed_nodes = user_quota.get('allowed_nodes', [])
    
    nodes = load_nodes()
    current_time = time.time()
    
    for node_id, node_info in nodes.items():
        node_info['status'] = 'offline' if current_time - node_info.get('last_heartbeat', 0) > 90 else 'online'
    
    # 如果不是管理員，且用戶有設定允許的節點，則過濾
    if role != 'admin' and allowed_nodes:
        nodes = {k: v for k, v in nodes.items() if k in allowed_nodes}
    
    return jsonify({'success': True, 'nodes': nodes})

@app.route('/api/node/<node_id>', methods=['DELETE'])
@admin_required
def delete_node(node_id):
    nodes = load_nodes()
    if node_id in nodes:
        # 獲取節點的 Token 並加入撤銷列表
        node_token = nodes[node_id].get('token')
        if node_token:
            revoke_token(node_token)
        
        del nodes[node_id]
        save_nodes(nodes)
        return jsonify({'success': True})
    return jsonify({'success': False, 'error': '節點不存在'}), 404

@app.route('/api/node/config', methods=['POST'])
@admin_required
def create_node_config():
    data = request.get_json()
    token = generate_token()
    token_id = str(uuid.uuid4())  # 額外的 token ID
    node_id = str(uuid.uuid4())   # Node UUID
    connection_url = data.get('connection_url', '')
    host = '0.0.0.0'  # 預設為 0.0.0.0
    port = 443  # 預設 HTTPS 端口
    
    if ':' in connection_url and not connection_url.startswith('http'):
        parts = connection_url.rsplit(':', 1)
        if len(parts) == 2 and parts[1].isdigit():
            host = parts[0]
            port = int(parts[1])
    elif connection_url.startswith('http://'):
        # HTTP 協議
        url_without_protocol = connection_url.replace('http://', '')
        if ':' in url_without_protocol:
            parts = url_without_protocol.rsplit(':', 1)
            if len(parts) == 2 and parts[1].isdigit():
                host = parts[0]
                port = int(parts[1])
    elif connection_url.startswith('https://'):
        # HTTPS 協議
        url_without_protocol = connection_url.replace('https://', '')
        if ':' in url_without_protocol:
            parts = url_without_protocol.rsplit(':', 1)
            if len(parts) == 2 and parts[1].isdigit():
                host = parts[0]
                port = int(parts[1])
    
    storage_limit = data.get('storage_limit', 0)
    redundancy = data.get('redundancy', 0)
    max_file_size = data.get('max_file_size', 100 * 1024 * 1024)  # 預設 100MB
    heartbeat_interval = data.get('heartbeat_interval', 30)  # 預設 30秒
    panel_url = data.get('panel_url', 'http://localhost:5000')
    
    nodes = load_nodes()
    nodes[node_id] = {
        'id': node_id,
        'token_id': token_id,
        'name': data.get('name', 'Unnamed Node'),
        'token': token,
        'host': host,
        'port': port,
        'connection_url': connection_url,
        'registered_at': time.time(),
        'last_heartbeat': 0,
        'status': 'pending',
        'capacity': storage_limit,
        'redundancy': redundancy,
        'storage_limit': storage_limit + int(storage_limit * redundancy / 100),
        'used': 0,
        'config_only': True
    }
    save_nodes(nodes)
    
    # 返回配置檔案格式 (YAML)
    node_name = data.get('name', 'Unnamed Node')
    config_content = f"""# HimService Node 配置檔案
# 請將此配置貼到 Node 端的 config.yml 中

uuid: "{node_id}"
token_id: "{token_id}"
token: "{token}"

node:
  name: "{node_name}"
  host: "{host}"
  port: {port}
  max_file_size: {max_file_size}
  max_storage_size: {storage_limit}
  data: "storage"

heartbeat_interval: {heartbeat_interval}
panel_url: "{panel_url}"
"""
    
    return jsonify({
        'success': True,
        'node_id': node_id,
        'token': token,
        'token_id': token_id,
        'config_content': config_content
    })

# Token API
@app.route('/api/token/generate', methods=['POST'])
@admin_required
def generate_node_token():
    return jsonify({'success': True, 'token': generate_token()})

# 檔案管理 API
@app.route('/api/file/upload', methods=['POST'])
@login_required
def upload_file():
    if 'file' not in request.files:
        return jsonify({'success': False, 'error': '無檔案'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'success': False, 'error': '檔案名稱為空'}), 400
    
    user_id = session.get('user_id')
    role = session.get('role')
    quotas = load_quotas()
    user_quota = quotas.get(user_id, {})
    allowed_nodes = user_quota.get('allowed_nodes', [])
    
    target_node_id = request.form.get('node_id')
    all_nodes = load_nodes()
    
    # 根據用戶權限過濾節點
    if role != 'admin' and allowed_nodes:
        nodes = {k: v for k, v in all_nodes.items() if k in allowed_nodes}
    else:
        nodes = all_nodes
    
    if target_node_id and target_node_id in nodes:
        node = nodes[target_node_id]
    else:
        online_nodes = [n for n in nodes.values() if n.get('status') == 'online']
        if not online_nodes:
            return jsonify({'success': False, 'error': '無可用節點'}), 500
        node = online_nodes[0]
    
    file_content = file.read()
    file_size = len(file_content)
    
    if user_quota.get('quota', 0) > 0:
        if user_quota.get('used', 0) + file_size > user_quota.get('quota', 0):
            return jsonify({'success': False, 'error': '儲存空間不足'}), 400
    
    files = load_files()
    file_id = str(uuid.uuid4())
    filename = secure_filename(file.filename)
    
    try:
        response = requests.post(f"http://{node['host']}:{node['port']}/api/node/store", files={'file': (filename, file_content)}, data={'file_id': file_id, 'user_id': user_id}, timeout=30)
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                files[file_id] = {'id': file_id, 'name': filename, 'size': file_size, 'node_id': node['id'], 'node_name': node['name'], 'user_id': user_id, 'uploaded_at': time.time(), 'checksum': result.get('checksum', '')}
                save_files(files)
                quotas[user_id]['used'] = quotas[user_id].get('used', 0) + file_size
                save_quotas(quotas)
                return jsonify({'success': True, 'file_id': file_id, 'node': node['name']})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    return jsonify({'success': False, 'error': '上傳失敗'}), 500

@app.route('/api/file/list', methods=['GET'])
@login_required
def list_files():
    user_id = session.get('user_id')
    role = session.get('role')
    files = load_files()
    if role == 'admin':
        return jsonify({'success': True, 'files': files})
    return jsonify({'success': True, 'files': {k: v for k, v in files.items() if v.get('user_id') == user_id}})

@app.route('/api/file/by-node/<node_id>', methods=['GET'])
@login_required
def list_files_by_node(node_id):
    user_id = session.get('user_id')
    role = session.get('role')
    files = load_files()
    node_files = {k: v for k, v in files.items() if v.get('node_id') == node_id}
    if role != 'admin':
        node_files = {k: v for k, v in node_files.items() if v.get('user_id') == user_id}
    return jsonify({'success': True, 'files': node_files})

@app.route('/api/file/download/<file_id>', methods=['GET'])
@login_required
def download_file(file_id):
    files = load_files()
    user_id = session.get('user_id')
    role = session.get('role')
    
    if file_id not in files:
        return jsonify({'success': False, 'error': '檔案不存在'}), 404
    
    file_info = files[file_id]
    if role != 'admin' and file_info.get('user_id') != user_id:
        return jsonify({'success': False, 'error': '無權存取'}), 403
    
    nodes = load_nodes()
    node = nodes.get(file_info['node_id'])
    if not node:
        return jsonify({'success': False, 'error': '節點不存在'}), 404
    
    try:
        response = requests.get(f"http://{node['host']}:{node['port']}/api/node/retrieve/{file_id}", timeout=30, stream=True)
        if response.status_code == 200:
            return send_file(response.raw, download_name=file_info['name'], as_attachment=True)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    return jsonify({'success': False, 'error': '下載失敗'}), 500

@app.route('/api/file/<file_id>', methods=['DELETE'])
@login_required
def delete_file(file_id):
    files = load_files()
    user_id = session.get('user_id')
    role = session.get('role')
    
    if file_id not in files:
        return jsonify({'success': False, 'error': '檔案不存在'}), 404
    
    file_info = files[file_id]
    if role != 'admin' and file_info.get('user_id') != user_id:
        return jsonify({'success': False, 'error': '無權存取'}), 403
    
    node_id = file_info['node_id']
    file_size = file_info.get('size', 0)
    nodes = load_nodes()
    
    # 嘗試刪除 Node 上的檔案
    if node_id in nodes:
        node = nodes[node_id]
        try:
            response = requests.delete(f"http://{node['host']}:{node['port']}/api/node/delete/{file_id}", timeout=10)
            if response.status_code != 200:
                result = response.json()
                return jsonify({'success': False, 'error': result.get('error', '刪除失敗')}), 500
        except Exception as e:
            return jsonify({'success': False, 'error': f'連線節點失敗: {str(e)}'}), 500
    
    del files[file_id]
    save_files(files)
    
    quotas = load_quotas()
    file_user_id = file_info.get('user_id')
    if file_user_id in quotas:
        quotas[file_user_id]['used'] = max(0, quotas[file_user_id].get('used', 0) - file_size)
        save_quotas(quotas)
    return jsonify({'success': True, 'message': '檔案已刪除'})

# 路由 - 使用範本檔案
@app.route('/')
def file_manager():
    return render_template('drive.html')

@app.route('/admin')
def admin_panel():
    return render_template('admin.html')

if __name__ == '__main__':
    init_data_files()
    print("HimService Panel 啟動中...")
    print("網盤界面: http://localhost:5000")
    print("後台管理: http://localhost:5000/admin")
    print("預設帳號: admin / admin123")
    app.run(host='0.0.0.0', port=5000, debug=True)
